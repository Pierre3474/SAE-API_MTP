<?php
require __DIR__ . '/../config/config.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $pass = $_POST['password'];
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if ($user && password_verify($pass, $user['password'])) {
        $_SESSION['user'] = $user['username'];
        header('Location: ../index.php');
        exit;
    } else {
        $error = 'Identifiants invalides';
    }
}
?>
<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><title>Connexion</title><link rel="stylesheet" href="../assets/css/styles.css"></head><body>
<div class="auth-container">
<h2>Connexion</h2>
<?php if($error): ?><p class="error"><?=htmlspecialchars($error)?></p><?php endif; ?>
<form method="post">
  <label>Email: <input type="email" name="email" required></label><br>
  <label>Mot de passe: <input type="password" name="password" required></label><br>
  <button type="submit">Se connecter</button>
</form>
<p>Pas encore inscrit? <a href="register.php">Inscription</a></p>
</div>
</body></html>