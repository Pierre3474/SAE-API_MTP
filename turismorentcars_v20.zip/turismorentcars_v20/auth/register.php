<?php
require __DIR__ . '/../config/config.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'] ?? '';
    if (!$email) {
        $error = 'Email invalide';
    } elseif (strlen($password) < 8) {
        $error = 'Mot de passe doit faire au moins 8 caractères';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'Email déjà utilisé';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username,email,password,is_verified) VALUES (?,?,?,1)");
            $stmt->execute([$email,$email,$hash]);
            header('Location: login.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><title>Inscription</title><link rel="stylesheet" href="../assets/css/styles.css"></head><body>
<div class="auth-container">
<h2>Inscription</h2>
<?php if($error): ?><p class="error"><?=htmlspecialchars($error)?></p><?php endif; ?>
<form method="post">
  <label>Email: <input type="email" name="email" required></label><br>
  <label>Mot de passe: <input type="password" name="password" required></label><br>
  <button type="submit">S'inscrire</button>
</form>
<p>Déjà inscrit? <a href="login.php">Connexion</a></p>
</div>
</body></html>