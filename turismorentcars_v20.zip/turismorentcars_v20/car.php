<?php
require __DIR__ . '/config/config.php';
$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM cars WHERE id = ?");
$stmt->execute([$id]);
$car = $stmt->fetch();
if (!$car) {
    header('Location: index.php');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['cart'][] = $car['id'];
    header('Location: cart.php');
    exit;
}
$images = [];
if (!empty($car['images'])) {
    $tmp = json_decode($car['images'], true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($tmp) && count($tmp) > 0) {
        $images = $tmp;
    }
}
if (empty($images) && !empty($car['image_url'])) {
    $images = [$car['image_url']];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title><?=htmlspecialchars($car['marque'].' '.$car['modele'])?></title>
  <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<header><div class="logo">NOVALOC</div><nav><a href="index.php">Accueil</a><a href="cart.php" class="cart-link">Panier (<?=count($_SESSION['cart']??[])?>)</a></nav></header>
<main style="padding-top:100px; max-width:800px; margin: auto;">
  <h2><?=htmlspecialchars($car['marque'].' '.$car['modele'])?></h2>
  <div class="carousel">
    <?php foreach($images as $img): ?>
      <img src="<?=htmlspecialchars($img)?>" style="width:100%; height:400px; object-fit:cover; margin-bottom:10px;">
    <?php endforeach; ?>
  </div>
  <form method="post">
    <label>Durée (mois): <input type="number" name="duration" value="1" min="1"></label><br>
    <label>Acompte (%): <input type="number" name="deposit" value="10" min="0" max="100"></label><br>
    <label>Kilométrage: <input type="number" name="km" value="100"></label><br>
    <button type="submit" style="padding:10px 20px;border:none;border-radius:20px;background:#e67e22;color:#fff;">Ajouter au panier</button>
  </form>
</main>
</body>
</html>
