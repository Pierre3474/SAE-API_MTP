
<?php
// Exemple de panier dynamique
session_start();
$total_price = 0.00;
$items = [
    ["nom" => "Voiture A", "prix" => 19.99],
    ["nom" => "Voiture B", "prix" => 24.99]
];

// Calculer le total
foreach ($items as $item) {
    $total_price += $item["prix"];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Abonnement dynamique - PayPal</title>
    <script src="https://www.paypal.com/sdk/js?client-id=AXmr7JAvSYPl5QKfzWmtV4ZfOSxu6MiFcTXn5_wxPaHqPDLbBUqiBknviCMa4LSSiKnx_oQN8k0I-GVO&components=buttons,subscriptions&vault=true&intent=subscription&currency=EUR"></script>
    <style>
        body { font-family: Arial; margin: 40px; }
        .box { border: 1px solid #ccc; padding: 20px; max-width: 600px; margin: auto; }
        .total { font-size: 1.2em; font-weight: bold; }
    </style>
</head>
<body>
    <div class="box">
        <h2>Votre panier</h2>
        <ul>
            <?php foreach ($items as $item): ?>
                <li><?php echo $item["nom"] . " - " . number_format($item["prix"], 2) . " €"; ?></li>
            <?php endforeach; ?>
        </ul>
        <p class="total">Total : <?php echo number_format($total_price, 2); ?> €</p>

        <label for="frequence">Choisissez la fréquence :</label>
        <select id="frequence">
            <option value="MONTH">Mensuel</option>
            <option value="YEAR">Annuel</option>
        </select>

        <div id="paypal-button-container" style="margin-top: 20px;"></div>
    </div>

    <script>
        let total = <?php echo json_encode($total_price); ?>;

        paypal.Buttons({
            createSubscription: function(data, actions) {
                const frequency = document.getElementById('frequence').value;

                return fetch('create-plan.php?price=' + total + '&interval=' + frequency)
                    .then(res => res.json())
                    .then(data => {
                        return actions.subscription.create({
                            plan_id: data.id
                        });
                    });
            },
            onApprove: function(data, actions) {
                alert('Abonnement confirmé ! ID : ' + data.subscriptionID);
            }
        }).render('#paypal-button-container');
    </script>
</body>
</html>
