
<?php
header('Content-Type: application/json');

$price = $_GET['price'] ?? 10.00;
$interval = $_GET['interval'] ?? 'MONTH';

echo json_encode([
    "id" => "P-MOCKPLAN123456789"
]);
?>
