<?php
require __DIR__ . '/config/config.php';
$cars=$pdo->query("SELECT * FROM cars")->fetchAll();
?>
<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><meta name="viewport"content="width=device-width,initial-scale=1.0"><title>NOVALOC</title><link rel="stylesheet"href="assets/css/styles.css"></head><body>
<header><div class="logo">NOVALOC</div><nav>
    <a href="auth/login.php">Connexion</a>
    <a href="auth/register.php">Inscription</a>
    <a href="cart.php" class="cart-link">Panier (<span id="cart-count">0</span>)</a>
</nav></header>
<div class="filter-banner">
  <div class="filter-item">Trier par<div class="dropdown"><button data-sortKey="prix"data-order="asc">Prix croissant</button><button data-sortKey="prix"data-order="desc">Prix décroissant</button></div></div>
  <div class="filter-item">Type<div class="dropdown"><button data-filter-key="type"data-filter="all">Tous</button><button data-filter-key="type"data-filter="Coupé sport">Coupé sport</button><button data-filter-key="type"data-filter="Berline">Berline</button><button data-filter-key="type"data-filter="SUV">SUV</button><button data-filter-key="type"data-filter="Cabriolet">Cabriolet</button><button data-filter-key="type"data-filter="Hatchback">Hatchback</button><button data-filter-key="type"data-filter="4X4">4X4</button><button data-filter-key="type"data-filter="Break">Break</button></div></div>
  <div class="filter-item">Motorisation<div class="dropdown"><button data-filter-key="motorisation"data-filter="all">Tous</button><button data-filter-key="motorisation"data-filter="Thermique">Thermique</button><button data-filter-key="motorisation"data-filter="Hybride">Hybride</button><button data-filter-key="motorisation"data-filter="Électrique">Électrique</button></div></div>
  <div class="filter-item">Marques<div class="dropdown"><button data-filter-key="marque"data-filter="all">Tous</button><button data-filter-key="marque"data-filter="Porsche">Porsche</button><button data-filter-key="marque"data-filter="BMW">BMW</button><button data-filter-key="marque"data-filter="Audi">Audi</button><button data-filter-key="marque"data-filter="Mercedes">Mercedes</button><button data-filter-key="marque"data-filter="Jaguar">Jaguar</button></div></div>
</div>
<div class="search-container"><input type="text"id="searchInput" placeholder="Rechercher un modèle..."class="search-input"></div>
<div id="no-results"class="no-results"style="display:none;">Aucune voiture trouvée. Redirection...</div>
<div class="cars-grid">
<?php foreach($cars as $car): ?>
  <div class="car-card"data-type="<?=htmlspecialchars($car['type'])?>"data-motorisation="<?=htmlspecialchars($car['motorisation'])?>"data-marque="<?=htmlspecialchars($car['marque'])?>"data-prix="<?=$car['prix']?>">
    <span class="badge"><?=htmlspecialchars($car['badge'])?></span>
    
    <img src="<?=htmlspecialchars($car['image_url'])?>"onclick="location.href='car.php?id=<?=$car['id']?>'">
    <div class="car-card-content"><h3><?=htmlspecialchars($car['marque'].' '.$car['modele'])?></h3><p><?=$car['prix']?> € / mois</p></div>
  </div>
<?php endforeach; ?>
</div>
<footer>&copy;<?=date('Y')?>NOVALOC</footer><script src="assets/js/filter.js"></script><script src="assets/js/cart.js"></script></body></html>