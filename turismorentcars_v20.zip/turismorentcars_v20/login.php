<?php
session_start();
require __DIR__.'/includes/db.php';
require __DIR__.'/includes/functions.php';
$error = '';
if($_SERVER['REQUEST_METHOD']==='POST') {
    if(loginUser($_POST['email'], $_POST['password'])) {
        header('Location: index.php');
        exit;
    }
    $error = 'Identifiants invalides';
}
?>
<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><title>Connexion</title>
<link rel="stylesheet" href="assets/css/styles.css"></head><body>
<div class="auth-form"><h2>Connexion</h2>
<?php if($error):?><p class="error"><?=htmlspecialchars($error)?></p><?php endif;?>
<form method="post">
<input type="email" name="email" placeholder="Email" required>
<input type="password" name="password" placeholder="Mot de passe" required>
<button type="submit">Se connecter</button>
</form>
<p><a href="register.php">Inscription</a></p>
</div></body></html>