<?php
session_start();
require __DIR__.'/includes/db.php';
require __DIR__.'/includes/functions.php';
$error = '';
if($_SERVER['REQUEST_METHOD']==='POST') {
    if(registerUser($_POST['username'], $_POST['email'], $_POST['password'])) {
        header('Location: login.php');
        exit;
    }
    $error = 'Erreur lors de l\'inscription';
}
?>
<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><title>Inscription</title>
<link rel="stylesheet" href="assets/css/styles.css"></head><body>
<div class="auth-form"><h2>Inscription</h2>
<?php if($error):?><p class="error"><?=htmlspecialchars($error)?></p><?php endif;?>
<form method="post">
<input type="text" name="username" placeholder="Nom d’utilisateur" required>
<input type="email" name="email" placeholder="Email" required>
<input type="password" name="password" placeholder="Mot de passe" required>
<button type="submit">S’inscrire</button>
</form>
<p><a href="login.php">Connexion</a></p>
</div></body></html>