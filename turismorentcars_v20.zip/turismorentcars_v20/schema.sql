-- schema.sql for db_URTADO
CREATE DATABASE IF NOT EXISTS `db_URTADO` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `db_URTADO`;
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) UNIQUE NOT NULL,
  `email` VARCHAR(100) UNIQUE NOT NULL,
  `password` VARCHAR(255),
  `oauth_provider` VARCHAR(20),
  `oauth_id` VARCHAR(255),
  `is_verified` TINYINT(1) NOT NULL DEFAULT 0,
  `verify_token` VARCHAR(64) DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
DROP TABLE IF EXISTS `admin_users`;
CREATE TABLE `admin_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO `admin_users` (username,password) VALUES ('admin','admin');
DROP TABLE IF EXISTS `cars`;
CREATE TABLE `cars` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `badge` VARCHAR(50),
  `marque` VARCHAR(100) NOT NULL,
  `modele` VARCHAR(100) NOT NULL,
  `type` VARCHAR(50) NOT NULL,
  `motorisation` VARCHAR(50) NOT NULL,
  `prix` DECIMAL(10,2) NOT NULL,
  `images` JSON NOT NULL,
  `image_url` VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `cars` (badge, marque, modele, `type`, motorisation, prix, images, image_url) VALUES
('Premium','Porsche','Model1','Coupé sport','Thermique',525,'["assets/images/cars/1_1.jpg", "assets/images/cars/1_2.jpg", "assets/images/cars/1_3.jpg", "assets/images/cars/1_4.jpg"]','assets/images/cars/1_1.jpg'),
('Sport','BMW','Model2','Berline','Hybride',550,'["assets/images/cars/2_1.jpg", "assets/images/cars/2_2.jpg", "assets/images/cars/2_3.jpg", "assets/images/cars/2_4.jpg"]','assets/images/cars/2_1.jpg'),
('Limited','Audi','Model3','SUV','Électrique',575,'["assets/images/cars/3_1.jpg", "assets/images/cars/3_2.jpg", "assets/images/cars/3_3.jpg", "assets/images/cars/3_4.jpg"]','assets/images/cars/3_1.jpg'),
('Exclusive','Mercedes','Model4','Cabriolet','Thermique',600,'["assets/images/cars/4_1.jpg", "assets/images/cars/4_2.jpg", "assets/images/cars/4_3.jpg", "assets/images/cars/4_4.jpg"]','assets/images/cars/4_1.jpg'),
('Premium','Jaguar','Model5','Hatchback','Hybride',625,'["assets/images/cars/5_1.jpg", "assets/images/cars/5_2.jpg", "assets/images/cars/5_3.jpg", "assets/images/cars/5_4.jpg"]','assets/images/cars/5_1.jpg'),
('Sport','Tesla','Model6','4X4','Électrique',650,'["assets/images/cars/6_1.jpg", "assets/images/cars/6_2.jpg", "assets/images/cars/6_3.jpg", "assets/images/cars/6_4.jpg"]','assets/images/cars/6_1.jpg'),
('Limited','Land Rover','Model7','Break','Thermique',675,'["assets/images/cars/7_1.jpg", "assets/images/cars/7_2.jpg", "assets/images/cars/7_3.jpg", "assets/images/cars/7_4.jpg"]','assets/images/cars/7_1.jpg'),
('Exclusive','Jeep','Model8','Coupé sport','Hybride',700,'["assets/images/cars/8_1.jpg", "assets/images/cars/8_2.jpg", "assets/images/cars/8_3.jpg", "assets/images/cars/8_4.jpg"]','assets/images/cars/8_1.jpg'),
('Premium','Ferrari','Model9','Berline','Électrique',725,'["assets/images/cars/9_1.jpg", "assets/images/cars/9_2.jpg", "assets/images/cars/9_3.jpg", "assets/images/cars/9_4.jpg"]','assets/images/cars/9_1.jpg'),
('Sport','Lamborghini','Model10','SUV','Thermique',750,'["assets/images/cars/10_1.jpg", "assets/images/cars/10_2.jpg", "assets/images/cars/10_3.jpg", "assets/images/cars/10_4.jpg"]','assets/images/cars/10_1.jpg'),
('Limited','Bentley','Model11','Cabriolet','Hybride',775,'["assets/images/cars/11_1.jpg", "assets/images/cars/11_2.jpg", "assets/images/cars/11_3.jpg", "assets/images/cars/11_4.jpg"]','assets/images/cars/11_1.jpg'),
('Exclusive','Volvo','Model12','Hatchback','Électrique',800,'["assets/images/cars/12_1.jpg", "assets/images/cars/12_2.jpg", "assets/images/cars/12_3.jpg", "assets/images/cars/12_4.jpg"]','assets/images/cars/12_1.jpg'),
('Premium','Renault','Model13','4X4','Thermique',825,'["assets/images/cars/13_1.jpg", "assets/images/cars/13_2.jpg", "assets/images/cars/13_3.jpg", "assets/images/cars/13_4.jpg"]','assets/images/cars/13_1.jpg'),
('Sport','Ford','Model14','Break','Hybride',850,'["assets/images/cars/14_1.jpg", "assets/images/cars/14_2.jpg", "assets/images/cars/14_3.jpg", "assets/images/cars/14_4.jpg"]','assets/images/cars/14_1.jpg'),
('Limited','Skoda','Model15','Coupé sport','Électrique',875,'["assets/images/cars/15_1.jpg", "assets/images/cars/15_2.jpg", "assets/images/cars/15_3.jpg", "assets/images/cars/15_4.jpg"]','assets/images/cars/15_1.jpg'),
('Exclusive','Porsche','Model16','Berline','Thermique',900,'["assets/images/cars/16_1.jpg", "assets/images/cars/16_2.jpg", "assets/images/cars/16_3.jpg", "assets/images/cars/16_4.jpg"]','assets/images/cars/16_1.jpg'),
('Premium','BMW','Model17','SUV','Hybride',925,'["assets/images/cars/17_1.jpg", "assets/images/cars/17_2.jpg", "assets/images/cars/17_3.jpg", "assets/images/cars/17_4.jpg"]','assets/images/cars/17_1.jpg'),
('Sport','Audi','Model18','Cabriolet','Électrique',950,'["assets/images/cars/18_1.jpg", "assets/images/cars/18_2.jpg", "assets/images/cars/18_3.jpg", "assets/images/cars/18_4.jpg"]','assets/images/cars/18_1.jpg'),
('Limited','Mercedes','Model19','Hatchback','Thermique',975,'["assets/images/cars/19_1.jpg", "assets/images/cars/19_2.jpg", "assets/images/cars/19_3.jpg", "assets/images/cars/19_4.jpg"]','assets/images/cars/19_1.jpg'),
('Exclusive','Jaguar','Model20','4X4','Hybride',1000,'["assets/images/cars/20_1.jpg", "assets/images/cars/20_2.jpg", "assets/images/cars/20_3.jpg", "assets/images/cars/20_4.jpg"]','assets/images/cars/20_1.jpg'),
('Premium','Tesla','Model21','Break','Électrique',1025,'["assets/images/cars/21_1.jpg", "assets/images/cars/21_2.jpg", "assets/images/cars/21_3.jpg", "assets/images/cars/21_4.jpg"]','assets/images/cars/21_1.jpg'),
('Sport','Land Rover','Model22','Coupé sport','Thermique',1050,'["assets/images/cars/22_1.jpg", "assets/images/cars/22_2.jpg", "assets/images/cars/22_3.jpg", "assets/images/cars/22_4.jpg"]','assets/images/cars/22_1.jpg'),
('Limited','Jeep','Model23','Berline','Hybride',1075,'["assets/images/cars/23_1.jpg", "assets/images/cars/23_2.jpg", "assets/images/cars/23_3.jpg", "assets/images/cars/23_4.jpg"]','assets/images/cars/23_1.jpg'),
('Exclusive','Ferrari','Model24','SUV','Électrique',1100,'["assets/images/cars/24_1.jpg", "assets/images/cars/24_2.jpg", "assets/images/cars/24_3.jpg", "assets/images/cars/24_4.jpg"]','assets/images/cars/24_1.jpg'),
('Premium','Lamborghini','Model25','Cabriolet','Thermique',1125,'["assets/images/cars/25_1.jpg", "assets/images/cars/25_2.jpg", "assets/images/cars/25_3.jpg", "assets/images/cars/25_4.jpg"]','assets/images/cars/25_1.jpg'),
('Sport','Bentley','Model26','Hatchback','Hybride',1150,'["assets/images/cars/26_1.jpg", "assets/images/cars/26_2.jpg", "assets/images/cars/26_3.jpg", "assets/images/cars/26_4.jpg"]','assets/images/cars/26_1.jpg'),
('Limited','Volvo','Model27','4X4','Électrique',1175,'["assets/images/cars/27_1.jpg", "assets/images/cars/27_2.jpg", "assets/images/cars/27_3.jpg", "assets/images/cars/27_4.jpg"]','assets/images/cars/27_1.jpg'),
('Exclusive','Renault','Model28','Break','Thermique',1200,'["assets/images/cars/28_1.jpg", "assets/images/cars/28_2.jpg", "assets/images/cars/28_3.jpg", "assets/images/cars/28_4.jpg"]','assets/images/cars/28_1.jpg'),
('Premium','Ford','Model29','Coupé sport','Hybride',1225,'["assets/images/cars/29_1.jpg", "assets/images/cars/29_2.jpg", "assets/images/cars/29_3.jpg", "assets/images/cars/29_4.jpg"]','assets/images/cars/29_1.jpg'),
('Sport','Skoda','Model30','Berline','Électrique',1250,'["assets/images/cars/30_1.jpg", "assets/images/cars/30_2.jpg", "assets/images/cars/30_3.jpg", "assets/images/cars/30_4.jpg"]','assets/images/cars/30_1.jpg');
-- 30 sample entries --
('Premium','Porsche','911 Turbo','Coupé sport','Thermique',1200.00,'[]',''),
('Sport','BMW','M4','Coupé sport','Thermique',950.00,'[]','');
