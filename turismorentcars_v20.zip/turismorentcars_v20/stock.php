<?php
header('Content-Type: application/json');
require __DIR__.'/includes/db.php';
require __DIR__.'/includes/functions.php';
if(isset($_GET['car_id'])) {
    echo json_encode(['stock' => getStock($_GET['car_id'])]);
} else {
    echo json_encode(['error' => 'car_id manquant']);
}
?>